import numpy as np


# ==========================================================
# TIME FEATURES
# ==========================================================
def create_time_features(df):

    dt = df["Datetime"]

    df["Hour"] = dt.dt.hour
    df["Day"] = dt.dt.day
    df["Month"] = dt.dt.month
    df["Year"] = dt.dt.year
    df["Week"] = dt.dt.isocalendar().week.astype(int)
    df["Quarter"] = dt.dt.quarter
    df["DayOfWeek"] = dt.dt.dayofweek
    df["DayOfYear"] = dt.dt.dayofyear

    df["Weekend"] = (
        df["DayOfWeek"] >= 5
    ).astype(int)

    df["Month_Start"] = (
        dt.dt.is_month_start
    ).astype(int)

    df["Month_End"] = (
        dt.dt.is_month_end
    ).astype(int)

    df["Quarter_Start"] = (
        dt.dt.is_quarter_start
    ).astype(int)

    df["Quarter_End"] = (
        dt.dt.is_quarter_end
    ).astype(int)

    return df


# ==========================================================
# CYCLIC FEATURES
# ==========================================================
def create_cyclic_features(df):

    df["Hour_Sin"] = np.sin(
        2 * np.pi * df["Hour"] / 24
    )

    df["Hour_Cos"] = np.cos(
        2 * np.pi * df["Hour"] / 24
    )

    df["Day_Sin"] = np.sin(
        2 * np.pi * df["Day"] / 31
    )

    df["Day_Cos"] = np.cos(
        2 * np.pi * df["Day"] / 31
    )

    df["Week_Sin"] = np.sin(
        2 * np.pi * df["Week"] / 52
    )

    df["Week_Cos"] = np.cos(
        2 * np.pi * df["Week"] / 52
    )

    df["Month_Sin"] = np.sin(
        2 * np.pi * df["Month"] / 12
    )

    df["Month_Cos"] = np.cos(
        2 * np.pi * df["Month"] / 12
    )

    return df


# ==========================================================
# LAG FEATURES
# ==========================================================
def create_lag_features(df, target):

    series = df[target]

    lag_values = [
        1,
        2,
        3,
        6,
        12,
        24,
        48,
        72,
        168,
        336,
        720
    ]

    for lag in lag_values:

        df[f"Lag_{lag}"] = (
            series.shift(lag)
        )

    return df


# ==========================================================
# ROLLING FEATURES
# ==========================================================
def create_rolling_features(df, target):

    series = df[target]

    windows = [
        3,
        6,
        12,
        24,
        48,
        168,
        720
    ]

    for w in windows:

        df[f"Rolling_Mean_{w}"] = (
            series
            .rolling(window=w)
            .mean()
        )

    df["Rolling_Std_24"] = (
        series
        .rolling(24)
        .std()
    )

    df["Rolling_Std_168"] = (
        series
        .rolling(168)
        .std()
    )

    return df


# ==========================================================
# EMA FEATURES
# ==========================================================
def create_ema_features(df, target):

    series = df[target]

    df["EMA_24"] = (
        series
        .ewm(span=24)
        .mean()
    )

    df["EMA_168"] = (
        series
        .ewm(span=168)
        .mean()
    )

    df["EMA_720"] = (
        series
        .ewm(span=720)
        .mean()
    )

    return df


# ==========================================================
# TREND FEATURES
# ==========================================================
def create_trend_features(df):

    df["Trend_24"] = (
        df["Lag_1"] -
        df["Lag_24"]
    )

    df["Trend_168"] = (
        df["Lag_1"] -
        df["Lag_168"]
    )

    df["Trend_720"] = (
        df["Lag_1"] -
        df["Lag_720"]
    )

    return df


# ==========================================================
# WEATHER FEATURES
# ==========================================================
def create_weather_features(df):

    if {
        "Temperature (°C)",
        "Humidity (%)"
    }.issubset(df.columns):

        df["Temp_Humidity"] = (
            df["Temperature (°C)"]
            *
            df["Humidity (%)"]
        )

    if {
        "Temperature (°C)",
        "Wind Speed (km/h)"
    }.issubset(df.columns):

        df["Temp_Wind"] = (
            df["Temperature (°C)"]
            *
            df["Wind Speed (km/h)"]
        )

    if {
        "Rain (mm)",
        "Humidity (%)"
    }.issubset(df.columns):

        df["Rain_Humidity"] = (
            df["Rain (mm)"]
            *
            df["Humidity (%)"]
        )

    return df


# ==========================================================
# CREATE FEATURE SET
# ==========================================================
def create_feature_set(
        df,
        target_col="Load (MW)"
):

    print(
        "\nCreating Advanced Features..."
    )

    df = create_time_features(df)

    df = create_cyclic_features(df)

    df = create_lag_features(
        df,
        target_col
    )

    df = create_rolling_features(
        df,
        target_col
    )

    df = create_ema_features(
        df,
        target_col
    )

    df = create_trend_features(df)

    df = create_weather_features(df)

    df.dropna(
        inplace=True
    )

    df.reset_index(
        drop=True,
        inplace=True
    )

    print(
        "Feature Shape :",
        df.shape
    )

    return df