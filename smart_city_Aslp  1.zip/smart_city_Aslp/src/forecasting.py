import numpy as np
import pandas as pd
from pathlib import Path


# ==========================================================
# FORECAST DIRECTORY
# ==========================================================
FORECAST_DIR = (
    Path(__file__).resolve().parent.parent
    / "outputs"
    / "forecasts"
)

FORECAST_DIR.mkdir(
    parents=True,
    exist_ok=True
)


# ==========================================================
# CREATE FUTURE DATETIME
# ==========================================================
def create_future_dataframe(
        last_datetime,
        hours
):

    future_df = pd.DataFrame({

        "Datetime": pd.date_range(

            start=last_datetime
            + pd.Timedelta(hours=1),

            periods=hours,

            freq="h"

        )

    })

    return future_df


# ==========================================================
# CREATE TIME FEATURES
# ==========================================================
def create_future_features(
        future_df
):

    dt = future_df["Datetime"]

    future_df["Hour"] = dt.dt.hour

    future_df["Day"] = dt.dt.day

    future_df["Week"] = (
        dt.dt.isocalendar()
        .week
        .astype(int)
    )

    future_df["Month"] = dt.dt.month

    future_df["Quarter"] = dt.dt.quarter

    future_df["Year"] = dt.dt.year

    future_df["DayOfWeek"] = dt.dt.dayofweek

    future_df["Weekend"] = (
        future_df["DayOfWeek"] >= 5
    ).astype(int)

    future_df["Hour_Sin"] = np.sin(
        2 * np.pi *
        future_df["Hour"] / 24
    )

    future_df["Hour_Cos"] = np.cos(
        2 * np.pi *
        future_df["Hour"] / 24
    )

    future_df["Month_Sin"] = np.sin(
        2 * np.pi *
        future_df["Month"] / 12
    )

    future_df["Month_Cos"] = np.cos(
        2 * np.pi *
        future_df["Month"] / 12
    )

    return future_df


# ==========================================================
# PREPARE FORECAST FEATURES
# ==========================================================
def prepare_forecast_features(

        future_df,

        feature_columns,

        reference_row

):

    missing_cols = [

        col

        for col in feature_columns

        if col not in future_df.columns

    ]

    if len(missing_cols) > 0:

        for col in missing_cols:

            future_df[col] = (
                reference_row[col]
            )

    return future_df[
        feature_columns
    ]


# ==========================================================
# GENERATE FORECAST
# ==========================================================
def generate_forecast(

        model,

        last_datetime,

        feature_columns,

        reference_row,

        hours

):

    future_df = create_future_dataframe(

        last_datetime,

        hours

    )

    future_df = create_future_features(
        future_df
    )

    X_future = prepare_forecast_features(

        future_df,

        feature_columns,

        reference_row

    )

    predictions = model.predict(
        X_future
    )

    forecast_df = pd.DataFrame({

        "Date":
        future_df["Datetime"]
        .dt.strftime("%d/%m/%Y"),

        "Time":
        future_df["Datetime"]
        .dt.strftime("%H:%M"),

        "Predicted_Load":
        predictions.round(2)

    })

    return forecast_df


# ==========================================================
# SAVE FORECAST
# ==========================================================
def save_forecast(

        forecast_df,

        filename

):

    output_path = (
        FORECAST_DIR
        / filename
    )

    forecast_df.to_excel(

        output_path,

        index=False

    )

    print(
        f"Saved : {output_path}"
    )


# ==========================================================
# CREATE ALL FORECASTS
# ==========================================================
def create_all_forecasts(

        model,

        last_datetime,

        feature_columns,

        reference_row

):

    periods = {

        "next_hour.xlsx": 1,

        "next_day.xlsx": 24,

        "next_week.xlsx": 168,

        "next_month.xlsx": 720,

        "next_quarter.xlsx": 2160,

        "next_half_year.xlsx": 4380,

        "next_year.xlsx": 8760

    }

    summary = {}

    for filename, hours in periods.items():

        forecast_df = generate_forecast(

            model=model,

            last_datetime=last_datetime,

            feature_columns=feature_columns,

            reference_row=reference_row,

            hours=hours

        )

        save_forecast(

            forecast_df,

            filename

        )

        summary[filename] = round(

            forecast_df[
                "Predicted_Load"
            ].sum(),

            2

        )

    return summary


# ==========================================================
# PRINT FORECAST SUMMARY
# ==========================================================
def print_forecast_summary(
        summary
):

    print("\n" + "=" * 70)

    print(
        "ASLP FUTURE FORECASTS"
    )

    print("=" * 70)

    for key, value in summary.items():

        print(

            f"{key:<20}"

            f"{value:.2f}"

        )

    print("=" * 70)


# ==========================================================
# SAVE FORECAST SUMMARY
# ==========================================================
def save_forecast_summary(
        summary
):

    summary_df = pd.DataFrame({

        "Forecast_Period":

        list(summary.keys()),

        "Predicted_Load":

        list(summary.values())

    })

    output_path = (

        FORECAST_DIR

        / "forecast_summary.xlsx"

    )

    summary_df.to_excel(

        output_path,

        index=False

    )

    print(
        "\nForecast Summary Saved"
    )

    print(
        output_path
    )