import warnings
warnings.filterwarnings("ignore")

from pathlib import Path
from sklearn.model_selection import train_test_split

from data_loader import (
    load_data,
    preprocess_data
)

from feature_engineering import (
    create_feature_set
)

from models import (
    train_random_forest,
    train_xgboost,
    train_lightgbm,
    train_extra_trees,
    train_catboost,
    train_aslp,
    predict_aslp,
    save_models
)

from evaluation import (
    evaluate_all_models,
    print_results,
    save_metrics,
    save_prediction_results
)

from forecasting import (
    create_all_forecasts,
    print_forecast_summary,
    save_forecast_summary,
    generate_forecast
)

from plotting import (
    generate_all_plots
)


# ==========================================================
# TARGET COLUMN
# ==========================================================
TARGET_COLUMN = "Load (MW)"


# ==========================================================
# MAIN
# ==========================================================
def main():

    print("=" * 70)
    print("ASLP V4 SMART LOAD PREDICTION")
    print("=" * 70)

    # ======================================================
    # PROJECT PATH
    # ======================================================
    project_root = (
        Path(__file__)
        .resolve()
        .parent
        .parent
    )

    # ======================================================
    # DATA PATH
    # ======================================================
    data_path = (
        project_root
        / "data"
        / "electricity_load_2020_2025.csv"
    )

    print("\nDataset Path:")
    print(data_path)

    # ======================================================
    # CREATE FOLDERS
    # ======================================================
    (
        project_root
        / "outputs"
        / "reports"
    ).mkdir(
        parents=True,
        exist_ok=True
    )

    (
        project_root
        / "outputs"
        / "plots"
    ).mkdir(
        parents=True,
        exist_ok=True
    )

    (
        project_root
        / "outputs"
        / "forecasts"
    ).mkdir(
        parents=True,
        exist_ok=True
    )

    (
        project_root
        / "models"
        / "saved_models"
    ).mkdir(
        parents=True,
        exist_ok=True
    )

    # ======================================================
    # LOAD DATA
    # ======================================================
    df = load_data(
        data_path
    )

    df = preprocess_data(
        df
    )

    # ======================================================
    # FEATURE ENGINEERING
    # ======================================================
    df = create_feature_set(
        df,
        TARGET_COLUMN
    )

    remove_cols = [

        "Date",

        "Time",

        "Datetime",

        TARGET_COLUMN

    ]

    feature_columns = [

        col

        for col in df.columns

        if col not in remove_cols

    ]

    X = df[
        feature_columns
    ].copy()

    y = df[
        TARGET_COLUMN
    ]

    # ======================================================
    # ENCODE OBJECT COLUMNS
    # ======================================================
    categorical_cols = (

        X.select_dtypes(
            include=["object"]
        ).columns

    )

    for col in categorical_cols:

        X[col] = (

            X[col]
            .astype("category")
            .cat.codes

        )

    # ======================================================
    # TRAIN TEST SPLIT
    # ======================================================
    X_train, X_test, y_train, y_test = train_test_split(

        X,
        y,

        test_size=0.20,

        shuffle=False

    )

    # ======================================================
    # TRAIN MODELS
    # ======================================================
    rf_model = train_random_forest(
        X_train,
        y_train
    )

    xgb_model = train_xgboost(
        X_train,
        y_train
    )

    lgbm_model = train_lightgbm(
        X_train,
        y_train
    )

    et_model = train_extra_trees(
        X_train,
        y_train
    )

    cat_model = train_catboost(
        X_train,
        y_train
    )

    aslp_model = train_aslp()

    # ======================================================
    # PREDICTIONS
    # ======================================================
    print("\nGenerating Predictions...")

    rf_pred = rf_model.predict(
        X_test
    )

    xgb_pred = xgb_model.predict(
        X_test
    )

    lgbm_pred = lgbm_model.predict(
        X_test
    )

    et_pred = et_model.predict(
        X_test
    )

    cat_pred = cat_model.predict(
        X_test
    )

    aslp_pred = predict_aslp(

        rf_pred,

        xgb_pred,

        lgbm_pred,

        et_pred,

        cat_pred,

        aslp_model

    )

    # ======================================================
    # EVALUATION
    # ======================================================
    metrics_df = evaluate_all_models(

        y_test,

        rf_pred,

        xgb_pred,

        lgbm_pred,

        aslp_pred

    )

    print_results(
        metrics_df
    )

    save_metrics(
        metrics_df
    )

    # ======================================================
    # SAVE PREDICTIONS
    # ======================================================
    prediction_dates = (

        df.iloc[
            len(df) - len(y_test):
        ]["Datetime"]

        .reset_index(
            drop=True
        )

    )

    save_prediction_results(

        prediction_dates,

        y_test.reset_index(
            drop=True
        ),

        aslp_pred,

        "prediction_results.xlsx"

    )

    # ======================================================
    # FORECASTS
    # ======================================================
    last_datetime = (
        df["Datetime"].iloc[-1]
    )

    reference_row = (
        X.iloc[-1]
    )

    forecast_summary = create_all_forecasts(

        model=lgbm_model,

        last_datetime=last_datetime,

        feature_columns=feature_columns,

        reference_row=reference_row

    )

    print_forecast_summary(
        forecast_summary
    )

    save_forecast_summary(
        forecast_summary
    )

    # ======================================================
    # 2026 FORECAST
    # ======================================================
    forecast_df = generate_forecast(

        model=lgbm_model,

        last_datetime=last_datetime,

        feature_columns=feature_columns,

        reference_row=reference_row,

        hours=8760

    )

    # ======================================================
    # PLOTS
    # ======================================================
    try:

        generate_all_plots(

            df=df,

            target_col=TARGET_COLUMN,

            y_test=y_test,

            y_pred=aslp_pred,

            metrics_df=metrics_df,

            feature_model=lgbm_model,

            feature_names=feature_columns,

            forecast_df=forecast_df

        )

    except Exception as e:

        print(
            "\nPlot Error:",
            e
        )

    # ======================================================
    # SAVE MODELS
    # ======================================================
    save_models(

        rf_model,

        xgb_model,

        lgbm_model,

        et_model,

        cat_model,

        aslp_model

    )

    print("\n" + "=" * 70)
    print("ASLP V4 TRAINING COMPLETED")
    print("=" * 70)


# ==========================================================
# RUN
# ==========================================================
if __name__ == "__main__":

    main()