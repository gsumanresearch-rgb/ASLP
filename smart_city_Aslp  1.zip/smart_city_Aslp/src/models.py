from pathlib import Path
import joblib

from sklearn.ensemble import (
    RandomForestRegressor,
    ExtraTreesRegressor
)

from xgboost import XGBRegressor
from lightgbm import LGBMRegressor
from catboost import CatBoostRegressor


# ==========================================================
# MODEL DIRECTORY
# ==========================================================
MODEL_DIR = (
    Path(__file__).resolve().parent.parent
    / "models"
    / "saved_models"
)

MODEL_DIR.mkdir(
    parents=True,
    exist_ok=True
)


# ==========================================================
# RANDOM FOREST
# ==========================================================
def train_random_forest(
        X_train,
        y_train
):

    print("\nTraining Random Forest...")

    model = RandomForestRegressor(

        n_estimators=300,
        max_depth=20,
        random_state=42,
        n_jobs=-1

    )

    model.fit(
        X_train,
        y_train
    )

    return model


# ==========================================================
# XGBOOST
# ==========================================================
def train_xgboost(
        X_train,
        y_train
):

    print("\nTraining XGBoost...")

    model = XGBRegressor(

        n_estimators=2000,
        learning_rate=0.015,
        max_depth=10,
        subsample=0.9,
        colsample_bytree=0.9,
        objective="reg:squarederror",
        random_state=42,
        n_jobs=-1

    )

    model.fit(
        X_train,
        y_train
    )

    return model


# ==========================================================
# LIGHTGBM
# ==========================================================
def train_lightgbm(
        X_train,
        y_train
):

    print("\nTraining LightGBM...")

    model = LGBMRegressor(

        n_estimators=2500,
        learning_rate=0.01,
        num_leaves=256,
        max_depth=18,
        min_child_samples=10,
        subsample=0.9,
        colsample_bytree=0.9,
        random_state=42,
        verbosity=-1,
        n_jobs=-1

    )

    model.fit(
        X_train,
        y_train
    )

    return model


# ==========================================================
# EXTRA TREES
# ==========================================================
def train_extra_trees(
        X_train,
        y_train
):

    print("\nTraining Extra Trees...")

    model = ExtraTreesRegressor(

        n_estimators=300,
        max_depth=20,
        random_state=42,
        n_jobs=-1

    )

    model.fit(
        X_train,
        y_train
    )

    return model


# ==========================================================
# CATBOOST
# ==========================================================
def train_catboost(
        X_train,
        y_train
):

    print("\nTraining CatBoost...")

    model = CatBoostRegressor(

        iterations=2000,
        learning_rate=0.03,
        depth=8,
        loss_function="RMSE",
        verbose=False,
        random_seed=42

    )

    model.fit(
        X_train,
        y_train
    )

    return model


# ==========================================================
# ASLP V4
# ==========================================================
def train_aslp():

    print("\nTraining ASLP V4...")

    aslp_model = {

        "rf_weight": 0.02,
        "xgb_weight": 0.25,
        "lgbm_weight": 0.45,
        "et_weight": 0.03,
        "cat_weight": 0.25

    }

    return aslp_model


# ==========================================================
# ASLP PREDICTION
# ==========================================================
def predict_aslp(

        rf_pred,
        xgb_pred,
        lgbm_pred,
        et_pred,
        cat_pred,
        aslp_model

):

    predictions = (

        aslp_model["rf_weight"] * rf_pred +

        aslp_model["xgb_weight"] * xgb_pred +

        aslp_model["lgbm_weight"] * lgbm_pred +

        aslp_model["et_weight"] * et_pred +

        aslp_model["cat_weight"] * cat_pred

    )

    return predictions


# ==========================================================
# SAVE MODELS
# ==========================================================
def save_models(

        rf_model,
        xgb_model,
        lgbm_model,
        et_model,
        cat_model,
        aslp_model

):

    models = {

        "random_forest.pkl": rf_model,
        "xgboost.pkl": xgb_model,
        "lightgbm.pkl": lgbm_model,
        "extra_trees.pkl": et_model,
        "catboost.pkl": cat_model,
        "aslp.pkl": aslp_model

    }

    for filename, model in models.items():

        joblib.dump(
            model,
            MODEL_DIR / filename
        )

    print(
        "\nModels Saved Successfully"
    )