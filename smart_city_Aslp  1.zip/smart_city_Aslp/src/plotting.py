import warnings
warnings.filterwarnings("ignore")

from pathlib import Path
import numpy as np
import pandas as pd

import matplotlib
matplotlib.use("Agg")

import matplotlib.pyplot as plt


# ==========================================================
# OUTPUT DIRECTORY
# ==========================================================
OUTPUT_DIR = (
    Path(__file__).resolve().parent.parent
    / "outputs"
    / "plots"
)

OUTPUT_DIR.mkdir(
    parents=True,
    exist_ok=True
)


# ==========================================================
# SAVE PLOT
# ==========================================================
def save_plot(filename):

    filepath = OUTPUT_DIR / filename

    plt.tight_layout()

    plt.savefig(
        filepath,
        dpi=300,
        bbox_inches="tight"
    )

    print(f"Saved : {filepath}")

    plt.close()


# ==========================================================
# MODEL ACCURACY
# ==========================================================
def plot_accuracy(metrics_df):

    plt.figure(figsize=(10, 6))

    colors = [
        "royalblue",
        "orange",
        "limegreen",
        "crimson"
    ]

    metrics_df["Accuracy"].plot(
        kind="bar",
        color=colors
    )

    plt.ylabel("Accuracy (%)")
    plt.title("Model Accuracy Comparison")
    plt.grid(alpha=0.3)

    save_plot(
        "01_model_accuracy_comparison.png"
    )


# ==========================================================
# MAE RMSE
# ==========================================================
def plot_mae_rmse(metrics_df):

    plt.figure(figsize=(10, 6))

    x = np.arange(
        len(metrics_df)
    )

    width = 0.35

    plt.bar(
        x - width / 2,
        metrics_df["MAE"],
        width,
        color="dodgerblue",
        label="MAE"
    )

    plt.bar(
        x + width / 2,
        metrics_df["RMSE"],
        width,
        color="orange",
        label="RMSE"
    )

    plt.xticks(
        x,
        metrics_df.index
    )

    plt.legend()

    plt.title(
        "MAE RMSE Comparison"
    )

    plt.grid(alpha=0.3)

    save_plot(
        "02_mae_rmse_comparison.png"
    )


# ==========================================================
# ACTUAL VS PREDICTED
# ==========================================================
def plot_actual_vs_predicted(
        y_true,
        y_pred
):

    plt.figure(figsize=(8, 8))

    plt.scatter(
        y_true,
        y_pred,
        alpha=0.3,
        color="purple"
    )

    mn = min(
        y_true.min(),
        y_pred.min()
    )

    mx = max(
        y_true.max(),
        y_pred.max()
    )

    plt.plot(
        [mn, mx],
        [mn, mx],
        color="red",
        linewidth=3
    )

    plt.xlabel("Actual")
    plt.ylabel("Predicted")

    plt.title(
        "Actual vs Predicted"
    )

    save_plot(
        "03_actual_vs_predicted.png"
    )


# ==========================================================
# RESIDUAL DISTRIBUTION
# ==========================================================
def plot_residual_distribution(
        y_true,
        y_pred
):

    residuals = (
        np.array(y_true)
        -
        np.array(y_pred)
    )

    plt.figure(figsize=(10, 6))

    plt.hist(
        residuals,
        bins=50,
        color="teal"
    )

    plt.axvline(
        0,
        color="red"
    )

    plt.title(
        "Residual Distribution"
    )

    save_plot(
        "04_residual_distribution.png"
    )


# ==========================================================
# FEATURE IMPORTANCE
# ==========================================================
def plot_feature_importance(
        model,
        feature_names
):

    if not hasattr(
            model,
            "feature_importances_"
    ):
        return

    importance = pd.DataFrame({

        "Feature":
        feature_names,

        "Importance":
        model.feature_importances_

    })

    importance = (
        importance
        .sort_values(
            "Importance",
            ascending=False
        )
        .head(15)
    )

    plt.figure(figsize=(10, 8))

    plt.barh(
        importance["Feature"],
        importance["Importance"],
        color="coral"
    )

    plt.gca().invert_yaxis()

    plt.title(
        "Top 15 Feature Importance"
    )

    save_plot(
        "05_feature_importance.png"
    )


# ==========================================================
# HOURLY LOAD PATTERN
# ==========================================================
def plot_hourly_pattern(
        df,
        target_col
):

    hourly = (
        df.groupby("Hour")[target_col]
        .mean()
    )

    plt.figure(figsize=(10, 6))

    plt.plot(
        hourly.index,
        hourly.values,
        color="green",
        linewidth=3
    )

    plt.fill_between(
        hourly.index,
        hourly.values,
        alpha=0.3
    )

    plt.title(
        "Hourly Load Pattern"
    )

    plt.xlabel(
        "Hour"
    )

    plt.ylabel(
        "Average Load"
    )

    save_plot(
        "06_hourly_pattern.png"
    )


# ==========================================================
# MONTHLY LOAD TREND
# ==========================================================
def plot_monthly_trend(
        df,
        target_col
):

    monthly = (
        df.groupby("Month")[target_col]
        .mean()
    )

    plt.figure(figsize=(10, 6))

    plt.plot(
        monthly.index,
        monthly.values,
        marker="o",
        linewidth=3,
        color="darkorange"
    )

    plt.xlabel(
        "Month"
    )

    plt.ylabel(
        "Average Load"
    )

    plt.title(
        "Monthly Load Trend"
    )

    save_plot(
        "07_monthly_trend.png"
    )


# ==========================================================
# FUTURE FORECAST
# ==========================================================
def plot_future_forecast(
        forecast_df
):

    if forecast_df is None:
        return

    plt.figure(figsize=(12, 6))

    plt.plot(
        forecast_df["Predicted_Load"],
        color="mediumseagreen",
        linewidth=2
    )

    plt.fill_between(
        np.arange(
            len(forecast_df)
        ),
        forecast_df["Predicted_Load"],
        alpha=0.3
    )

    plt.title(
        "Future Load Forecast"
    )

    save_plot(
        "08_future_forecast.png"
    )


# ==========================================================
# RADAR CHART
# ==========================================================
def plot_radar_chart(
        metrics_df
):

    plt.figure(figsize=(8, 6))

    for model in metrics_df.index:

        plt.plot(
            ["Accuracy", "R2"],
            [
                metrics_df.loc[model, "Accuracy"],
                metrics_df.loc[model, "R2"] * 100
            ],
            marker="o",
            linewidth=3,
            label=model
        )

    plt.legend()

    plt.title(
        "Model Performance"
    )

    save_plot(
        "09_radar_chart.png"
    )


# ==========================================================
# GENERATE ALL PLOTS
# ==========================================================
def generate_all_plots(
        df,
        target_col,
        y_test,
        y_pred,
        metrics_df,
        feature_model,
        feature_names,
        forecast_df
):

    print("\nGenerating Plots...")

    plot_accuracy(metrics_df)

    plot_mae_rmse(metrics_df)

    plot_actual_vs_predicted(
        y_test,
        y_pred
    )

    plot_residual_distribution(
        y_test,
        y_pred
    )

    plot_feature_importance(
        feature_model,
        feature_names
    )

    plot_hourly_pattern(
        df,
        target_col
    )

    plot_monthly_trend(
        df,
        target_col
    )

    plot_future_forecast(
        forecast_df
    )

    plot_radar_chart(
        metrics_df
    )

    plt.close("all")

    print(
        "\n9 colorful plots generated successfully."
    )