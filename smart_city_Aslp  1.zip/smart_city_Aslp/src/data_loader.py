import numpy as np
import pandas as pd
from pathlib import Path


# ==========================================================
# LOAD DATA
# ==========================================================
def load_data(file_path):

    file_path = Path(file_path)

    if not file_path.exists():
        raise FileNotFoundError(
            f"Dataset not found:\n{file_path}"
        )

    suffix = file_path.suffix.lower()

    if suffix == ".csv":
        df = pd.read_csv(file_path)

    elif suffix in [".xls", ".xlsx"]:
        df = pd.read_excel(file_path)

    else:
        raise ValueError(
            "Unsupported file format."
        )

    print("\nLoading Dataset...")
    print("Shape :", df.shape)

    return df


# ==========================================================
# DATETIME PROCESSING
# ==========================================================
def process_datetime(df):

    if (
        "Date" in df.columns
        and
        "Time" in df.columns
    ):

        df["Datetime"] = pd.to_datetime(

            df["Date"].astype(str)
            + " "
            + df["Time"].astype(str),

            dayfirst=True,
            errors="coerce"

        )

    else:

        datetime_cols = [

            "Datetime",
            "DateTime",
            "datetime",
            "Timestamp",
            "timestamp"

        ]

        datetime_col = next(

            (
                col
                for col in datetime_cols
                if col in df.columns
            ),

            None

        )

        if datetime_col is None:

            raise ValueError(
                "Datetime column not found."
            )

        df["Datetime"] = pd.to_datetime(

            df[datetime_col],

            dayfirst=True,
            errors="coerce"

        )

    df.dropna(
        subset=["Datetime"],
        inplace=True
    )

    df.sort_values(
        "Datetime",
        inplace=True
    )

    df.reset_index(
        drop=True,
        inplace=True
    )

    return df


# ==========================================================
# REMOVE DUPLICATES
# ==========================================================
def remove_duplicates(df):

    duplicates = df.duplicated().sum()

    if duplicates > 0:

        print(
            f"Removing {duplicates} duplicate rows..."
        )

        df.drop_duplicates(
            inplace=True
        )

        df.reset_index(
            drop=True,
            inplace=True
        )

    return df


# ==========================================================
# HANDLE MISSING VALUES
# ==========================================================
def handle_missing_values(df):

    numeric_cols = df.select_dtypes(
        include=np.number
    ).columns

    df[numeric_cols] = df[numeric_cols].fillna(
        df[numeric_cols].median()
    )

    object_cols = df.select_dtypes(
        include=["object"]
    ).columns

    for col in object_cols:

        mode_value = df[col].mode()

        if len(mode_value) > 0:

            df[col] = df[col].fillna(
                mode_value.iloc[0]
            )

    return df


# ==========================================================
# OUTLIER CLIPPING
# ==========================================================
def clip_outliers(df):

    numeric_cols = df.select_dtypes(
        include=np.number
    ).columns

    q01 = df[numeric_cols].quantile(
        0.01
    )

    q99 = df[numeric_cols].quantile(
        0.99
    )

    df[numeric_cols] = df[numeric_cols].clip(

        lower=q01,
        upper=q99,
        axis=1

    )

    return df


# ==========================================================
# VALIDATE DATA
# ==========================================================
def validate_data(df):

    if df.empty:

        raise ValueError(
            "Dataset is empty."
        )

    return df


# ==========================================================
# PREPROCESS DATA
# ==========================================================
def preprocess_data(df):

    df = process_datetime(df)

    df = remove_duplicates(df)

    df = handle_missing_values(df)

    df = clip_outliers(df)

    df = validate_data(df)

    print(
        "\nFinal Shape :",
        df.shape
    )

    return df


# ==========================================================
# TEST
# ==========================================================
if __name__ == "__main__":

    DATA_PATH = (
        "/storage/emulated/0/"
        "ALSP/smart_city_Aslp/"
        "smart_city_Aslp/data/"
        "electricity_load_2020_2025.csv"
    )

    df = load_data(DATA_PATH)

    df = preprocess_data(df)

    print("\nColumns:")
    print(df.columns.tolist())

    print("\nFirst 5 Rows:")
    print(df.head())