import numpy as np
import pandas as pd
from pathlib import Path

from sklearn.metrics import (
    mean_absolute_error,
    mean_squared_error,
    r2_score
)


# ==========================================================
# REPORT DIRECTORY
# ==========================================================
REPORT_DIR = (
    Path(__file__).resolve().parent.parent
    / "outputs"
    / "reports"
)

REPORT_DIR.mkdir(
    parents=True,
    exist_ok=True
)


# ==========================================================
# CALCULATE METRICS
# ==========================================================
def calculate_metrics(
        y_true,
        y_pred
):

    mae = mean_absolute_error(
        y_true,
        y_pred
    )

    rmse = np.sqrt(
        mean_squared_error(
            y_true,
            y_pred
        )
    )

    r2 = r2_score(
        y_true,
        y_pred
    )

    mape = np.mean(
        np.abs(
            (y_true - y_pred)
            / y_true
        )
    ) * 100

    return {

        "MAE": round(
            mae,
            4
        ),

        "RMSE": round(
            rmse,
            4
        ),

        "R2": round(
            r2,
            4
        ),

        "MAPE": round(
            mape,
            4
        ),

        "Accuracy": round(
            r2 * 100,
            2
        )

    }


# ==========================================================
# EVALUATE ALL MODELS
# ==========================================================
def evaluate_all_models(

        y_test,
        rf_pred,
        xgb_pred,
        lgbm_pred,
        aslp_pred

):

    predictions = {

        "Random Forest": rf_pred,

        "XGBoost": xgb_pred,

        "LightGBM": lgbm_pred,

        "ASLP": aslp_pred

    }

    metrics = {

        model:
        calculate_metrics(
            y_test,
            pred
        )

        for model, pred
        in predictions.items()

    }

    metrics_df = pd.DataFrame(
        metrics
    ).T

    metrics_df.index.name = "Model"

    return metrics_df


# ==========================================================
# PRINT RESULTS
# ==========================================================
def print_results(
        metrics_df
):

    print("\n" + "=" * 70)
    print("ASLP RESULTS")
    print("=" * 70)

    for model, row in metrics_df.iterrows():

        print(

            f"{model:<15}"

            f" Accuracy={row['Accuracy']:.2f}%"

            f" MAE={row['MAE']:.2f}"

            f" RMSE={row['RMSE']:.2f}"

        )

    best_model = (
        metrics_df["Accuracy"]
        .idxmax()
    )

    best_accuracy = (
        metrics_df["Accuracy"]
        .max()
    )

    print("\n" + "=" * 70)

    print(
        f"BEST MODEL : {best_model}"
    )

    print(
        f"BEST ACCURACY : {best_accuracy:.2f}%"
    )

    print("=" * 70)

    return (
        best_model,
        best_accuracy
    )


# ==========================================================
# SAVE METRICS
# ==========================================================
def save_metrics(
        metrics_df
):

    output_path = (
        REPORT_DIR
        / "model_metrics.csv"
    )

    metrics_df.to_csv(
        output_path
    )

    print(
        "\nMetrics saved:"
    )

    print(
        output_path
    )


# ==========================================================
# SAVE PREDICTIONS
# ==========================================================
def save_prediction_results(

        dates,
        y_test,
        y_pred,
        file_name="prediction_results.xlsx"

):

    output_path = (
        REPORT_DIR
        / file_name
    )

    result_df = pd.DataFrame({

        "Date":
        dates.dt.strftime(
            "%d/%m/%Y"
        ),

        "Time":
        dates.dt.strftime(
            "%H:%M"
        ),

        "Actual_Load":
        y_test,

        "Predicted_Load":
        y_pred

    })

    result_df["Error"] = (

        result_df["Actual_Load"]

        -

        result_df["Predicted_Load"]

    )

    if file_name.endswith(
            ".csv"
    ):

        result_df.to_csv(

            output_path,

            index=False

        )

    else:

        result_df.to_excel(

            output_path,

            index=False

        )

    print(
        "\nPrediction file saved:"
    )

    print(
        output_path
    )

    return result_df